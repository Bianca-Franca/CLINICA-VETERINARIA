# APS-2021---CL-NICA-VETERIN-RIA
PROJETO FINAL
Clínica veterinária

Justificativa: Com a alta demanda de agendamentos e clientes, faz-se necessário a criação de um um sistema para uma melhor organização de tarefas e otimização do tempo.

Descrição: O sistema Clínica Veterinária v1.0 é uma solução para automatização de clínicas veterinárias. Nesse sentido, o sistema fornece funcionalidades para automatizar o processo de cadastro de clientes, agendamento de atendimentos, além da escolha do(s) serviço(s) (banho, tosa, consulta, etc).

Especificação do papel de cada membro: • Alexandre Souza de Brito (proprietário da clínica); • Simone Gonçalves de Oliveira (Secretária de Alexandre); • Grupo (Bianca, Emanuela e Laiza).
